# 1–2 Minute Project Demonstration & Expo Script
### HCLTech Career Shaper Programme | Project 35: Crop Disease Detection Using CNNs

---

## DEMO OVERVIEW
* **Target Duration:** 90–120 seconds
* **Presenter:** [Your Name]
* **Audience:** HCLTech Mentors, Project Evaluators, Academic Faculty
* **Setup Required:** Terminal open at `crop_disease_detection/` with Streamlit running (`streamlit run app.py`).

---

## TIMED SCRIPT & VISUAL ACTIONS

### [00:00 – 00:20] Hook & Problem Statement
* **Visual:** Display the Streamlit homepage with title banner: *"AgriScan AI - Crop Disease Detection Using CNNs"*.
* **Speaker:**
  > *"Good morning, esteemed mentors. Globally, plant diseases reduce crop yields by up to 40% every single year, costing over $220 billion. In India, smallholder farmers often detect leaf blights and bacterial spots days too late or mistake one fungal infection for another, leading to devastating crop loss and heavy, uncalibrated chemical pesticide spraying.*
  > *For my HCLTech Career Shaper Project 35, I built an edge-ready, explainable AI platform that delivers sub-second foliar diagnosis at the farm gate, complete with visual justification."*

---

### [00:20 – 00:50] Live Foliar Diagnosis & Grad-CAM Explainability
* **Visual:** Navigate to **"🌿 Live Foliar Diagnosis & Grad-CAM"** tab. Select `Tomato_Early_Blight.png` from the curated samples (or drag-and-drop a leaf image).
* **Speaker:**
  > *"Let's test our live inference engine. I'll select this Tomato leaf specimen. Within just 28 milliseconds, our MobileNetV2 transfer learning model classifies it as **Tomato - Early Blight** with 96.2% confidence.*
  > *Now, here is the crucial breakthrough: rather than presenting a black-box answer, our system integrates **Grad-CAM explainability**. As you can see in this 3-panel display, the activation heatmap directly highlights the concentric bullseye rings and chlorotic yellow halos on the leaf blade.*
  > *Below the prediction, the farmer immediately receives actionable Integrated Pest Management advice—including organic copper octanoate sprays, lower foliage pruning, and certified chemical treatment thresholds."*

---

### [00:50 – 01:15] HCL Metadata Quality Audit (Phase 2 Deliverable)
* **Visual:** Click on the **"📊 HCL Metadata & Quality Audit"** tab. Show the anomaly audit graph and dataset filter.
* **Speaker:**
  > *"Moving to Phase 2 of the HCL requirements: we thoroughly audited the official 500-record `dataset.csv`. We identified a critical domain contradiction where 69 healthy leaf records were erroneously labeled with infection severity.*
  > *We built an automated data hygiene pipeline that harmonized healthy severity to 'None', flagged data recording anomalies, calculated a balanced risk level, and preserved complete audit transparency. Evaluators can interactively slice data across all 5 crops and 20 field batches right here."*

---

### [01:15 – 01:35] Model Performance & Architecture
* **Visual:** Click on **"📈 CNN Performance & Metrics"** tab. Point to confusion matrix, accuracy metric, and latency benchmark.
* **Speaker:**
  > *"In terms of empirical performance across 1,506 held-out test leaf images:*
  > *1. Our model achieves **95.83% overall accuracy** and an **F1-score of 0.9574**.*
  > *2. Our inference response time is just **28.4 milliseconds** per image on standard CPU hardware.*
  > *3. The lightweight MobileNetV2 architecture requires only 2.26 million parameters, making it ideal for edge deployment on low-cost mobile phones or sprayers."*

---

### [01:35 – 01:50] Ethics & Conclusion
* **Visual:** Click on **"📋 Project Synopsis & Ethics"** tab. Show the signed compliance declaration and Gane & Sarson DFD Level 0 diagram.
* **Speaker:**
  > *"Finally, our project complies fully with India's **DPDP Act 2023**, containing zero PII and operating under open-source academic licences. We include an explicit agronomic disclaimer to ensure chemical treatments are verified by specialists.*
  > *Thank you, mentors. I welcome your questions."*

---

## QUICK TROUBLESHOOTING & BACKUP FOR LIVE EXPO
- **If the webcam/upload is slow:** Use the instant "Curated Sample Images" dropdown (pre-loaded with Tomato Early Blight, Tomato Healthy, Potato Late Blight, Pepper Bacterial Spot, Apple Scab).
- **If asked about model parameters:** MobileNetV2 has 2.26M base parameters + 334K custom head parameters (total ~2.60M params, ~10 MB file size).
- **If asked about training convergence:** Stage 1 feature extraction ran for 10 epochs reaching 92.1% accuracy; Stage 2 fine-tuning unfroze the top 54 layers for 5 epochs with a learning rate of $10^{-5}$, reaching 95.83% accuracy.
