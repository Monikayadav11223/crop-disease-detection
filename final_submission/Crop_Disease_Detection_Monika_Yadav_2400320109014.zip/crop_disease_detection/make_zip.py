"""
make_zip.py - Repackage the project ZIP excluding caches and virtual envs.
"""
import zipfile
import os

proj = r"C:\Users\Dell\.gemini\antigravity\scratch\crop_disease_detection"
zip_path = os.path.join(proj, "Crop_Disease_Detection_HCL.zip")

exclude_dirs = {"__pycache__", ".git", "venv", "env", "temp_mpl", "final_submission"}
exclude_exts = {".zip", ".pyc"}

added = []
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as zf:
    for root, dirs, files in os.walk(proj):
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".")]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in exclude_exts:
                continue
            fpath = os.path.join(root, f)
            arcname = os.path.relpath(fpath, proj)
            zf.write(fpath, arcname)
            added.append(arcname)

size = os.path.getsize(zip_path)
print(f"Files added: {len(added)}")
print(f"ZIP size: {size:,} bytes  ({size/1024:.1f} KB)")
print("")
for a in sorted(added):
    print(f"  {a}")
