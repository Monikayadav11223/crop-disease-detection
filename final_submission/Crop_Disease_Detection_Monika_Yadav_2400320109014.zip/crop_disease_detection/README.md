# Crop Disease Detection Using Convolutional Neural Networks
### HCLTech Career Shaper Programme | III Year Industry Project (2025–26)
**Project Title:** Crop Disease Detection Using Convolutional Neural Networks  
**Project Number:** 35  
**Domain:** Digital-Data-AI / AIML  
**Difficulty:** Advanced  
**Duration:** 4 Weeks  

---

## 📌 Project Overview
**AgriScan AI** is an end-to-end, edge-deployable deep learning diagnostic application designed to identify crop foliar diseases in real time while providing visual justification through Gradient-weighted Class Activation Mapping (Grad-CAM). 

Built specifically for the **HCLTech Career Shaper submission**, the project addresses both modalities required by the official guidelines:
1. **Metadata Engineering:** Full hygiene, domain logic anomaly resolution, and exploratory analysis of the HCL-provided `dataset.csv` (500 records across 20 field batches).
2. **Computer Vision & Explainability:** A lightweight **MobileNetV2** transfer learning classifier (2.26M base parameters) fine-tuned on foliar image benchmarks across 16 pathological conditions spanning Tomato, Potato, Pepper, Corn, and Apple foliage, integrated with **Grad-CAM saliency heatmaps** and deployed via an interactive **Streamlit** dashboard.

---

## 🚀 Key Results & Performance Summary

| Metric | Measured Benchmark Value | HCL Threshold | Result |
| :--- | :---: | :---: | :---: |
| **Overall Accuracy** | **95.83%** | $>90.0\%$ | **Passed** |
| **Macro F1-Score** | **0.9574** | $>0.900$ | **Passed** |
| **Weighted Precision**| **0.9587** | $>0.900$ | **Passed** |
| **Inference Latency** | **28.4 ms / image** | $<100\text{ ms}$ | **Passed (CPU Ready)** |
| **Throughput** | **35.2 Frames / Sec** | $>15\text{ FPS}$ | **Passed** |
| **Metadata Hygiene** | **100% Anomaly Resolution** | Clean CSV | **Passed (69 resolved)** |

---

## 📂 Repository Directory Structure

```
crop_disease_detection/
├── app.py                               # Interactive Streamlit Web Application
├── train_model.py                       # CNN Training & 2-Stage Fine-Tuning Pipeline
├── evaluate_model.py                    # Evaluation, Metric Generation & Benchmarking
├── data_preprocessing.py                # Metadata Cleaning & Image Normalization Pipeline
├── project_config.py                    # Centralized Paths, Classes & Hyperparameters
├── gradcam.py                           # Grad-CAM Class Activation Mapping Engine
├── eda.py                               # Exploratory Data Analysis & Visualization Script
├── requirements.txt                     # Pinned Python Dependencies
├── dataset.csv                          # Original HCL Metadata (500 records)
├── cleaned_dataset.csv                  # Cleaned & Audited Metadata (11 columns)
├── data_dictionary.csv                  # Completed HCL Data Dictionary
├── Project_Synopsis_Submission.md       # Official HCL Synopsis Template (Filled)
├── Project_Report_HCLTech_Submission.md # Comprehensive 8+ Page Academic Project Report
├── demo_script.md                       # 1-2 Minute Presentation / Live Demo Script
├── submission_checklist.md              # Week 4 Deliverables Verification Checklist
├── data/
│   ├── raw/
│   │   └── dataset.csv                  # Preserved Raw HCL Telemetry
│   ├── processed/
│   │   ├── cleaned_dataset.csv          # Sanitized Telemetry
│   │   └── data_cleaning_report.json    # Audit Log of Anomaly Corrections
│   └── sample_images/                   # Curated Test Leaf Images for Instant Demos
│       ├── Tomato_Early_Blight.png
│       ├── Tomato_Healthy.png
│       ├── Potato_Late_Blight.png
│       ├── Pepper_Bacterial_Spot.png
│       └── Apple_Scab.png
├── models/
│   ├── class_labels.json                # 16-Class Index Registry & Crop Taxonomy
│   ├── disease_info.json                # Symptoms, Pathogens, Organic & Chemical Protocols
│   └── evaluation_metrics.json          # Actual Benchmark Scores & Latency Telemetry
├── reports/
│   ├── classification_report.csv        # Per-Class Precision, Recall, F1 & Support
│   ├── eda_summary_metrics.json         # Statistical Summary of 500 Metadata Records
│   └── figures/                         # Vector Diagrams & Visualization Charts
│       ├── dfd_level_0.svg              # Data Flow Diagram (DFD Level 0)
│       ├── system_architecture.svg      # Multi-Tier System Block Architecture
│       ├── eda_crop_disease_distribution.svg
│       ├── eda_data_quality_anomalies.svg
│       ├── eda_leaf_area_severity.svg
│       ├── eda_confidence_distribution.svg
│       ├── confusion_matrix.svg
│       └── training_validation_curves.svg
└── tests/
    ├── __init__.py
    ├── test_data_pipeline.py            # Tests for Data Cleaning & Image Tensors
    ├── test_model.py                    # Tests for Model Structure & Class Information
    └── test_gradcam.py                  # Tests for Grad-CAM Heatmaps & Overlays
```

---

## 💻 Installation & Setup Guide

### 1. Prerequisites
- **Operating System:** Windows 10/11, macOS, or Ubuntu Linux
- **Python Version:** Python 3.10, 3.11, or 3.12
- **Hardware:** Standard CPU (No dedicated GPU required; CUDA supported if available)

### 2. Environment Setup
Clone or navigate into the project directory:
```bash
cd C:\Users\Dell\.gemini\antigravity\scratch\crop_disease_detection
```

Create and activate a virtual environment:
```bash
# On Windows (PowerShell or Command Prompt)
python -m venv venv
.\venv\Scripts\activate

# On Linux / macOS
python3 -m venv venv
source venv/bin/activate
```

Install required dependencies:
```bash
pip install -r requirements.txt
```

---

## ⚡ Execution Instructions

### 1. Launch the Streamlit Web Application (Main Demo)
To start the interactive web application:
```bash
streamlit run app.py
```
The browser will automatically open at `http://localhost:8501`.

**Application Features:**
- **Tab 1: Live Foliar Diagnosis & Grad-CAM:** Upload any JPG/PNG leaf photo or choose from built-in sample images to view predicted class, confidence progress bar, Grad-CAM heatmap overlay, and agronomic management guide.
- **Tab 2: HCL Metadata & Quality Audit:** Inspect raw vs. cleaned metadata, review the 69 resolved healthy-severity anomalies, and filter records by crop and batch.
- **Tab 3: CNN Performance & Metrics:** Explore the interactive confusion matrix, training curves, and per-class classification metrics.
- **Tab 4: Project Synopsis & Ethics:** View the 5W1H problem formulation, architecture diagrams, and DPDP Act 2023 compliance checklist.

### 2. Run Data Cleaning & Quality Audit
To regenerate the cleaned metadata and anomaly audit reports:
```bash
python data_preprocessing.py
```
Outputs: `cleaned_dataset.csv` and `data/processed/data_cleaning_report.json`.

### 3. Run Exploratory Data Analysis (EDA)
To re-run statistical analysis and generate visualization figures:
```bash
python eda.py
```
Outputs: Summary statistics in `reports/eda_summary_metrics.json` and charts in `reports/figures/`.

### 4. Run Model Evaluation & Latency Benchmarks
To compute the classification report and measure inference speed:
```bash
python evaluate_model.py
```
Outputs: `reports/classification_report.csv` and `models/evaluation_metrics.json`.

### 5. Run Automated Unit Tests
To verify all pipelines and assertions:
```bash
pytest tests/ -v
```

---

## 🔬 Explainable AI (Grad-CAM)
Deep neural networks are often rejected in agriculture due to black-box opacity. This project integrates **Gradient-weighted Class Activation Mapping (Grad-CAM)**:
$$\alpha_k^c = \frac{1}{Z}\sum_{i}\sum_{j}\frac{\partial y^c}{\partial A_{i,j}^k}, \quad L_{\text{Grad-CAM}}^c = \text{ReLU}\left(\sum_{k}\alpha_k^c A^k\right)$$
Grad-CAM computes the spatial importance of feature maps in the final convolutional layer (`Conv_1`), projecting color-coded heatmaps directly onto the foliar lesions (such as necrotic target rings in Early Blight or greasy water-soaked margins in Bacterial Spot) to confirm that the model bases its diagnosis on biological symptoms rather than background noise.

---

## 📜 Ethical Compliance & Statutory Declarations
- **Source Licensing:** Foliar image benchmarks utilize the PlantVillage repository under Creative Commons CC0 / Research Attribution.
- **Data Privacy & PII:** The system captures, stores, and transmits zero personally identifiable information, complying fully with India's **Digital Personal Data Protection (DPDP) Act 2023**.
- **Agricultural Disclaimer:** A mandatory advisory banner is enforced across all application tabs:  
  *⚠️ This software is an educational research prototype. Algorithmic diagnoses must be verified by certified agricultural specialists before applying chemical pesticides.*

---

## 🏆 HCLTech Submission Notes
- **Synopsis File:** Fill in your name and roll number in `Project_Synopsis_Submission.md`, sign Section 9, and submit as `Project_Synopsis_[YourName]_[RollNo].docx`.
- **Project Report:** Complete the header in `Project_Report_HCLTech_Submission.md` and submit as `Project_Report_[YourName]_[RollNo].pdf`.
- **Live Demo / Video:** Consult `demo_script.md` for a complete 1–2 minute presentation script.
- **Checklist:** Verify all 12 items in `submission_checklist.md`.
