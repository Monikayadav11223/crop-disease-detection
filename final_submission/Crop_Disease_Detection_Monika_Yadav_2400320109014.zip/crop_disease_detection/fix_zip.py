"""
fix_zip.py
Creates a clean, verified ZIP of the crop disease detection project.
Saves to the Windows Desktop.
"""
import os
import zipfile

# ── Paths ──────────────────────────────────────────────────────────────────────
PROJ_DIR  = r"C:\Users\Dell\.gemini\antigravity\scratch\crop_disease_detection"
ZIP_NAME  = "Crop_Disease_Detection_HCL_FIXED.zip"
ZIP_PATH  = os.path.join(PROJ_DIR, ZIP_NAME)   # written to project folder first

# ── Exclusion rules ────────────────────────────────────────────────────────────
SKIP_DIRS = {"__pycache__", ".git", "venv", "env", "temp_mpl",
             "final_submission", ".idea", ".vscode"}
SKIP_EXTS = {".pyc", ".pyo"}
SKIP_FILES = {"fix_zip.py", "make_zip.py"}          # helper scripts
# Exclude existing ZIPs inside the project itself
SKIP_EXTS_NAMES = {".zip"}

# ── Collect files ──────────────────────────────────────────────────────────────
entries = []   # list of (absolute_path, archive_name)

for root, dirs, files in os.walk(PROJ_DIR):
    # Prune excluded directories in-place
    dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]

    for fname in sorted(files):
        ext = os.path.splitext(fname)[1].lower()
        if ext in SKIP_EXTS or ext in SKIP_EXTS_NAMES:
            continue
        if fname in SKIP_FILES:
            continue
        abs_path = os.path.join(root, fname)
        arc_name = os.path.relpath(abs_path, PROJ_DIR)
        entries.append((abs_path, arc_name))

print(f"Files to archive: {len(entries)}")
print()

# ── Write ZIP ──────────────────────────────────────────────────────────────────
os.makedirs(PROJ_DIR, exist_ok=True)

with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED,
                     compresslevel=6, allowZip64=True) as zf:
    for abs_path, arc_name in entries:
        zf.write(abs_path, arc_name)
        print(f"  + {arc_name}")

zip_size = os.path.getsize(ZIP_PATH)
print()
print(f"ZIP written : {ZIP_PATH}")
print(f"ZIP size    : {zip_size:,} bytes  ({zip_size / 1024:.1f} KB)")

# ── Verify: read back every file in the archive ───────────────────────────────
print()
print("Verifying archive integrity ...")
with zipfile.ZipFile(ZIP_PATH, "r") as zf:
    bad = zf.testzip()          # returns None if everything is OK
    names = zf.namelist()

if bad:
    print(f"ERROR: first bad file in archive -> {bad}")
else:
    print(f"Integrity check PASSED  ({len(names)} files, no corrupt entries)")

print()
print("Archive contents:")
for n in sorted(names):
    print(f"  {n}")
